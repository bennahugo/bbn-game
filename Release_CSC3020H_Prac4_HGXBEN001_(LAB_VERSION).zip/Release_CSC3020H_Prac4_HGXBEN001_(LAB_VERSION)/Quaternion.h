/*
 * Quaternion.h
 *
 *  Created on: Apr 2, 2012
 *      Author: benna
 *
 *  Quaternions is very useful for rotation of vectors in Euclidian 3-space (they do not suffer from gimbal lock). They are tuples of the form (a,b)
 *  where a is a Real number and b is a vector of imaginary numbers. For our purposes this vector can be represented using a vector of Real numbers,
 *  provided that quaternion-multiplication obey the property i*j*k = -1 and a^2=-1 where a is i,j,k (the basis for the vector space).
 *
 *  The normal binary operators are defined in terms of scalar multiplication and Quaternion addition, subtraction and multiplication. The set of
 *  quaternions conform to all the properties of a Field (Linear Algebra) except commutivity.
 *
 *	Sources:
 *	Quaternions and Rotation Sequences: A Primer with Applications to Orbits, Aerospace and Virtual Reality, J. B. Kuipers, ISBN 0691102988
 *		--- available from the Chancelor Oppenheimer Library
 *	http://content.gpwiki.org/index.php/OpenGL:Tutorials:Using_Quaternions_to_represent_rotation
 */

#ifndef QUATERNION_H_
#define QUATERNION_H_
#include "Vector3.h"
#include "Matrix4.h"


class Quaternion{
private:
	double realComponent;
	Vector3 imaginaryVector;
	Quaternion(){/*DO NOT INVOKE*/}
public:
	Quaternion(double rScalar,const Vector3 & vImaginary){
		realComponent = rScalar;
		imaginaryVector = vImaginary;
	}
	virtual ~Quaternion(){}
	Quaternion operator=(const Quaternion & rhs){
		if (&rhs != &*this){
			realComponent = rhs.realComponent;
			imaginaryVector = rhs.imaginaryVector;
		}
		return *this;
	}
	Quaternion operator+(const Quaternion & rhs){
		return Quaternion(realComponent+rhs.realComponent,imaginaryVector+rhs.imaginaryVector);
	}
	Quaternion operator-(const Quaternion & rhs){
		return Quaternion(realComponent-rhs.realComponent,imaginaryVector-rhs.imaginaryVector);
	}
	Quaternion operator*(double scalar){
		return Quaternion(realComponent*scalar,imaginaryVector*scalar);
	}
	Quaternion operator*(const Quaternion & q){
		return Quaternion(realComponent*q.realComponent-Vector3::dot(imaginaryVector,q.imaginaryVector),
				q.imaginaryVector*realComponent+imaginaryVector*q.realComponent+Vector3::cross(imaginaryVector,q.imaginaryVector));
	}
	Quaternion operator*(const Vector3 & v){
		return Quaternion(-Vector3::dot(imaginaryVector,v),v*realComponent+Vector3::cross(imaginaryVector,v));
	}
	double norm(){
		return sqrt(realComponent*realComponent+imaginaryVector.x*imaginaryVector.x+
				imaginaryVector.y*imaginaryVector.y+imaginaryVector.z*imaginaryVector.z);
	}
	void normalize(){
		double n = norm();
		realComponent = realComponent/n;
		imaginaryVector = imaginaryVector*(1/n);
	}
	Quaternion conjugate(){
		return Quaternion(realComponent,imaginaryVector*(-1));
	}
	void rotateVector(Vector3 & v){
		v = ((*this)*v*this->conjugate()).imaginaryVector;
	}
	void getAxisAngleRotation(double *angle, Vector3 *axis){
		axis->x = this->imaginaryVector.x;
		axis->y = this->imaginaryVector.y;
		axis->z = this->imaginaryVector.z;
		axis->normalize();
		*angle = acos(this->realComponent) * 2.0f;
	}
	/*
	 * Method to efficiently convert from Euler to Quaternion
	 * Source: http://content.gpwiki.org/index.php/OpenGL:Tutorials:Using_Quaternions_to_represent_rotation
	 */
	//static Quaternion ConvertFromEuler(float pitch, float yaw, float roll)
	static Quaternion ConvertFromEuler(float yaw, float roll, float pitch)
	{
		float p = pitch / 2.0;
		float y = yaw / 2.0;
		float r = roll / 2.0;

		float sinp = sin(p);
		float siny = sin(y);
		float sinr = sin(r);
		float cosp = cos(p);
		float cosy = cos(y);
		float cosr = cos(r);

		Quaternion result(cosr * cosp * cosy + sinr * sinp * siny,
				Vector3(sinr * cosp * cosy - cosr * sinp * siny,
						cosr * sinp * cosy + sinr * cosp * siny,
						cosr * cosp * siny - sinr * sinp * cosy));
		result.normalize();
		return result;
	}
	/*
	 * Method to convert quaternion to OpenGL style, column major format matrix
	 * Source: http://content.gpwiki.org/index.php/OpenGL:Tutorials:Using_Quaternions_to_represent_rotation
	 */
	Matrix4 getMatrix() const
	{
		float x2 = this->imaginaryVector.x * this->imaginaryVector.x;
		float y2 = this->imaginaryVector.y * this->imaginaryVector.y;
		float z2 = this->imaginaryVector.z * this->imaginaryVector.z;
		float xy = this->imaginaryVector.x * this->imaginaryVector.y;
		float xz = this->imaginaryVector.x * this->imaginaryVector.z;
		float yz = this->imaginaryVector.y * this->imaginaryVector.z;
		float wx = this->realComponent * this->imaginaryVector.x;
		float wy = this->realComponent * this->imaginaryVector.y;
		float wz = this->realComponent * this->imaginaryVector.z;
		// This calculation would be a lot more complicated for non-unit length quaternions
		// Note: The constructor of Matrix4 expects the Matrix in column-major format like expected by
		//   OpenGL
		return Matrix4( 1.0f - 2.0f * (y2 + z2), 2.0f * (xy - wz), 2.0f * (xz + wy), 0.0f,
					2.0f * (xy + wz), 1.0f - 2.0f * (x2 + z2), 2.0f * (yz - wx), 0.0f,
					2.0f * (xz - wy), 2.0f * (yz + wx), 1.0f - 2.0f * (x2 + y2), 0.0f,
					0.0f, 0.0f, 0.0f, 1.0f);
	}
};

#endif /* QUATERNION_H_ */
