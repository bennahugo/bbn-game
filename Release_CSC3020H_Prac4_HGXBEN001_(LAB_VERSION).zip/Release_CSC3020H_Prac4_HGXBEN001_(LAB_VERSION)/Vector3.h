/*
 * Vector3.h
 *
 *  Created on: Mar 17, 2012
 *      Author: benna
 *  	Calculus Concepts and Contexts, James Stewart 4th, ISBN: 0-495-56065-0
 */

#ifndef VECTOR3_H_
#define VECTOR3_H_
#include "math.h"
//A basic cartesian 3-space vector class, with some operator overloading to take care of addition, scalar multiplication, etc.
class Vector3 {
public:
	double x,y,z;
	Vector3(double X = 0, double Y = 0, double Z = 0):x(X),y(Y),z(Z){}
	virtual ~Vector3(){}
	Vector3 & operator=(const Vector3 & aVector){
		x = aVector.x;
		y = aVector.y;
		z = aVector.z;
		return *this;
	}
	Vector3 operator+(const Vector3 & aVector) const{
		return Vector3(aVector.x+x,aVector.y+y,aVector.z+z);
	}
	Vector3 operator-(const Vector3 & aVector) const{
			return Vector3(aVector.x-x,aVector.y-y,aVector.z-z);
	}
	Vector3 operator*(const double &scalarMultiple) const{
		return Vector3(x*scalarMultiple,y*scalarMultiple,z*scalarMultiple);
	}
	static Vector3 cross(const Vector3 & v1,const Vector3 & v2){
		return Vector3(v1.y*v2.z - v1.z*v2.y,v1.z*v2.x - v1.x*v2.z,v1.x*v2.y - v1.y*v2.x);
	}
	static double dot(const Vector3 & v1, const Vector3 & v2){
		return v1.x*v2.x+v1.y*v2.y+v1.z*v2.z;
	}
	double magnitude(){
		return sqrt(x*x+y*y+z*z);
	}
	void normalize(){
		double m = this->magnitude();
		x = x/m;
		y = y/m;
		z = z/m;
	}
};

#endif /* VECTOR3_H_ */
