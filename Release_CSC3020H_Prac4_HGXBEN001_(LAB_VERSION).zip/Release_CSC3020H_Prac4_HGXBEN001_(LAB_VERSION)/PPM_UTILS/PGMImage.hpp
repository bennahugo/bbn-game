/*
 * PGMImage.hpp
 *
 *  Created on: Mar 12, 2012
 *      Author: benna
 */

#ifndef PGMIMAGE_HPP_
#define PGMIMAGE_HPP_
#include <cstddef>
#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include "pixel_traits.hpp"
#include <boost/algorithm/string.hpp>

#include "lighten_functor.hpp"
#include "darken_functor.hpp"
#include "invert_functor.hpp"
#include "rgb.hpp"
#include "PGM_PPM_Header_Reader.h"
namespace HGXBEN001 {
template <typename T, typename Traits=pixel_traits<T> >
class PGMImage {
public:
	typedef typename Traits::pixel_type pixel;
public:
	/************************************************************************************************************************************************
	 * iterator inner-class:
	 ************************************************************************************************************************************************/
	class Iterator{
	private:
		class DirectionalUnit{
		private:
			DirectionalUnit(){};
			DirectionalUnit(Iterator & parentIterator, unsigned int MaxBound = (unsigned int)0,unsigned int value = (unsigned int)0,
								unsigned int dimIncrement=(unsigned int)1):maxBound(MaxBound),currentValue(value),dimensionalIncrement(dimIncrement),p(&parentIterator){};
			DirectionalUnit(const DirectionalUnit & d){
				this->currentValue = d.currentValue;
				this->maxBound = d.maxBound;
				this->dimensionalIncrement = d.dimensionalIncrement;
			}
			unsigned int maxBound;
			unsigned int currentValue;
			unsigned int dimensionalIncrement;
			Iterator * p;

		public:
			friend class Iterator;
			virtual ~DirectionalUnit(){}
			unsigned int operator*(){return currentValue;};
			DirectionalUnit & operator++(){
				if (++currentValue > maxBound)
					currentValue = maxBound;
				else{
					p->current1DIndex+=dimensionalIncrement;
				}
				return *this;
			}
			DirectionalUnit & operator--(){
				if (--currentValue < 0)
					currentValue = 0;
				else
					p->current1DIndex-=dimensionalIncrement;
				return *this;
			}
		};
		Iterator(){}
		Iterator(PGMImage & p,unsigned int maxWidth = (unsigned int)0,unsigned int maxHeight = (unsigned int)0,unsigned int currentX = (unsigned int)0,
				unsigned int currentY = (unsigned int)0):
					current1DIndex(currentX+currentY*maxWidth),x(DirectionalUnit(*this,maxWidth,currentX)),
					y(DirectionalUnit(*this,maxHeight,currentY,maxWidth)),ptrContainer(&p){}
		unsigned int current1DIndex;
		PGMImage * ptrContainer;

	public:
		friend class PGMImage;
		Iterator(const Iterator & anIterator){
			this->current1DIndex = anIterator.current1DIndex;
			this->ptrContainer = anIterator.ptrContainer;
			this->x = DirectionalUnit(anIterator.x);
			this->y = DirectionalUnit(anIterator.y);
			this->x.p = this;
			this->y.p = this;
		}
		virtual ~Iterator(){ }
		pixel & operator *(){
			return (ptrContainer->buffer[current1DIndex]);
		}
		DirectionalUnit x,y;
	};
	/************************************************************************************************************************************************
	 * const_iterator inner-class:
	************************************************************************************************************************************************/
	class const_iterator{
	private:
		class DirectionalUnit{
		private:
			DirectionalUnit(){};
			DirectionalUnit(const_iterator & parentIterator, unsigned int MaxBound = (unsigned int)0,unsigned int value = (unsigned int)0,
					unsigned int dimIncrement=(unsigned int)1):maxBound(MaxBound),currentValue(value),dimensionalIncrement(dimIncrement),p(&parentIterator){};
			DirectionalUnit(const DirectionalUnit & d){
				this->currentValue = d.currentValue;
				this->maxBound = d.maxBound;
				this->dimensionalIncrement = d.dimensionalIncrement;
			}
			unsigned int maxBound;
			unsigned int currentValue;
			unsigned int dimensionalIncrement;
			const_iterator * p;

		public:
			friend class const_iterator;
			virtual ~DirectionalUnit(){}
			inline unsigned int operator*(){return currentValue;}
			inline DirectionalUnit & operator++(){
				if (++currentValue > maxBound)
					currentValue = maxBound;
				else{
					p->current1DIndex+=dimensionalIncrement;
				}
				return *this;
			}
			inline DirectionalUnit & operator--(){
				if (--currentValue < 0)
					currentValue = 0;
				else
					p->current1DIndex-=dimensionalIncrement;
				return *this;
			}
		};
		const_iterator(){}
		const_iterator(const PGMImage & p,unsigned int maxWidth = (unsigned int)0,unsigned int maxHeight = (unsigned int)0,unsigned int currentX = (unsigned int)0,
				unsigned int currentY = (unsigned int)0):
					current1DIndex(currentX+currentY*maxWidth),x(DirectionalUnit(*this,maxWidth,currentX)),
					y(DirectionalUnit(*this,maxHeight,currentY,maxWidth)),ptrContainer(&p){}
		unsigned int current1DIndex;
		const PGMImage * ptrContainer;

	public:
		friend class PGMImage;
		const_iterator(const const_iterator & anIterator){
			this->current1DIndex = anIterator.current1DIndex;
			this->ptrContainer = anIterator.ptrContainer;
			this->x = DirectionalUnit(anIterator.x);
			this->y = DirectionalUnit(anIterator.y);
			this->x.p = this;
			this->y.p = this;
		}
		virtual ~const_iterator(){ }
		inline const pixel & operator *() const{					//THIS IS A CONST ITERATOR, PREVENT MODIFICATION
			return (ptrContainer->buffer[current1DIndex]);
		}
		DirectionalUnit x,y;
	};
/************************************************************************************************************************************************
 * image class declaration:
************************************************************************************************************************************************/
private:
	pixel * buffer;
	unsigned int width;
	unsigned int height;

	bool reallocate(unsigned int & X, unsigned int & Y){ //Assumption: This method resizes the image (I think it should crop it/extend the "canvas")
		if (buffer != NULL)
		{
			PGMImage::pixel * newbuffer = new PGMImage::pixel[((X)*(Y))];

			for (unsigned int j = 0; j < (Y); ++j)
				for (unsigned int i = 0; i < (X); ++i)
			{
				if ( (width < i) && (X < width ))
				{
					i = 0;
					j++;
				}
				else if (i > width || j > height)
				{
					newbuffer[i+j*X] = 30;
				}
				else
					newbuffer[i+j*X] = buffer[i+j*width];
			}
			freeContent();
			buffer = newbuffer;
			width = X; height = Y;
		}
		return false;
	}
	void clearCanvas(unsigned int & X, unsigned int & Y){
		PGMImage::pixel * newbuffer = new PGMImage::pixel[((X)*(Y))];
		for (unsigned int i = 0; i < X*Y; i++)
			newbuffer[i] = 0;
		buffer = newbuffer;
	}
public:
	//Constructors and destructors:
	PGMImage(unsigned int Width = 10, unsigned int Height = 10):width(Width),height(Height){
	buffer = new PGMImage::pixel[(width)*(height)];
		for (unsigned int i = 0; i < width*height; ++i)
			buffer[i] = 0;				//init to 0
	}
	PGMImage(const PGMImage & anImage) {
		width = anImage.width;
		height = anImage.height;
		buffer = new pixel[width*height];
		for (unsigned int i=0; i < width*height; i++)
			*(buffer+i) = *(anImage.buffer+i);
	}
	virtual ~PGMImage(){
		freeContent();
	}
	void freeContent(){
		if (buffer != NULL)
		{
			width = 0;
			height = 0;
			delete [] buffer;
			buffer = NULL;
		}
	}

	//Getters and Setters:
	const unsigned int & getWidth() const{
		return width;
	}
	const unsigned int & getHeight() const{
		return height;
	}
	//Iterator methods:
	Iterator begin(void){
		return Iterator(*this, width, height);
	}
	Iterator end(void){
		return Iterator(*this, width, height, width, height);
	}
	Iterator begin_at(unsigned int x, unsigned int y){
		return Iterator(*this, width, height, x, y);
	}
	Iterator end_at(unsigned int x, unsigned int y){
		return Iterator(*this, width, height, x + 1, y + 1);
	}

	const const_iterator begin(void) const{
		const_iterator c(*this, width, height);
		return c;
	}
	const const_iterator end(void) const{
		const_iterator c(*this, width, height, width, height);
		return c;
	}
	const const_iterator begin_at(unsigned int x, unsigned int y) const{
		const_iterator c(*this, width, height, x, y);
		return c;
	}
	const const_iterator end_at(unsigned int x, unsigned int y) const{
		const_iterator c(*this, width, height, x + 1, y + 1);
		return c;
	}

	//Overloaded operators:
	PGMImage & operator = (const PGMImage & anImage){
		if (&anImage != &*this){
			freeContent();
			width = anImage.width;
			height = anImage.height;
			buffer = new pixel[width*height];
			for (unsigned int i=0; i < width*height; i++)
				*(buffer+i) = *(anImage.buffer+i);
		}
		return *this;
	}
	pixel & operator ()(unsigned int & X, unsigned int & Y){return buffer[X+width*Y];}
	const pixel & operator ()(unsigned int & X, unsigned int & Y) const{return buffer[X+width*Y]; }

	template <typename AValueType>
	friend std::istream & operator >> (std::istream &in, PGMImage<AValueType> & thing);
	template <typename AValueType>
	friend std::istream & operator >> (std::istream &in, PGMImage<rgb<AValueType> > & thing);

	template <typename AValueType>
	friend std::ostream & operator << (std::ostream &out, const PGMImage<AValueType> & thing);
	template <typename AValueType>
	friend std::ostream & operator << (std::ostream &out, const PGMImage<rgb<AValueType> > & thing);

	template <typename AValueType>
	friend void getImagePixelBuffer(const PGMImage<AValueType> & inputImg,AValueType * targetBuffer);
	template <typename AValueType>
	friend void getImagePixelBuffer(const PGMImage<rgb<AValueType> > & inputImg,AValueType * targetBuffer);
	//template <> friend std::ostream & operator<< <typename RGBPixel>(std::ostream &out, const PGMImage<RGBPixel<T> > & thing);
};
/************************************************************************************************************************************************
 * Image manipulation operations:
************************************************************************************************************************************************/
/*
Algorithms to convert the Endian types of both simple and RGB buffers
Basically using some consecutive bit shifting and masking
*/
template <typename T> 
void convertEndian(T * buffer, long blockSize){
	for (long i = 0; i < blockSize; ++i){
		T val = 0;
		for (int j = 0; j < sizeof(T); ++j){
			val = val << 8;
			val = val | ((buffer[i] >> j*8) & 0xFF);
		}
		buffer[i] = val;
	}
} 
template <typename T> 
void convertEndian(rgb<T> * buffer, long blockSize){
	for (long i = 0; i < blockSize; ++i){
		T val = 0;
		for (int j = 0; j < sizeof(T); ++j){
			val = val << 8;
			val = val | ((buffer[i].r >> j*8) & 0xFF);
		}
		buffer[i].r = val;
		val = 0;
		for (int j = 0; j < sizeof(T); ++j){
			val = val << 8;
			val = val | ((buffer[i].g >> j*8) & 0xFF);
		}
		buffer[i].g = val;
		val = 0;
		for (int j = 0; j < sizeof(T); ++j){
			val = val << 8;
			val = val | ((buffer[i].b >> j*8) & 0xFF);
		}
		buffer[i].b = val;
	}
}
//image transform algorithm that will iterate through the image, applying some functor
template<typename Iterator,typename RetIterator, typename Functor>
void img_transform(Iterator first, Iterator last,
		RetIterator result, Functor functor)
{
	unsigned int originalXBegin = *first.x;
		while (*first.y < *last.y){
			while (*first.x < *last.x){
				*result = functor(*first);
				++first.x;
				++result.x;
			}
			while (*first.x > originalXBegin){
				--first.x;
				--result.x;
			}
			++first.y;
			++result.y;
		}
}

//This function does not modify the pixels, it just iterates over them. A funtor can then save the values in each to do calculations at a later stage
template<typename Iterator, typename Functor>
void img_for_each(Iterator first, Iterator last, Functor functor)
{
	unsigned originalXBegin = *first.x;
			while (*first.y < *last.y){
				while (*first.x < *last.x){

					functor(*first);
					++first.x;
				}
				while (*first.x > originalXBegin){
					--first.x;
				}
				++first.y;
			}
}

//data stream -- in operator. Loads an image from the file
template <typename AValueType>
std::istream & operator>>(std::istream &in,PGMImage<AValueType> & thing){
	typedef pixel_traits<AValueType> Traits;
	thing.freeContent();
	std::string * magicNo = new std::string;
	int * maxPixVal = new int;
	unsigned int * width = new unsigned int;
	unsigned int * height = new unsigned int;
	inspect_header(in, *magicNo, *maxPixVal, *width, *height);
	thing.width = *width;
	thing.height = *height;
	thing.clearCanvas(*width,*height);

	if (!in.read((char *)thing.buffer,(*width)*(*height)*sizeof(typename Traits::value_type)))//Since size of char is 1 we can safely just multiply with the size of the type we are casting to
		std::cout << "The image file is broken. Please inspect the input file." << std::endl;
	convertEndian(thing.buffer,(*width)*(*height));
	delete magicNo;
	delete maxPixVal;
	delete width;
	delete height;
	return in;
}
template <typename T> std::istream & operator>> (std::istream &in,PGMImage<rgb<T> > & thing){
	typedef pixel_traits<rgb<T> > Traits;
	typedef typename Traits::value_type rgbPixelValueType;
		thing.freeContent();
		std::string * magicNo = new std::string;
		int * maxPixVal = new int;
		unsigned int * width = new unsigned int;
		unsigned int * height = new unsigned int;
		inspect_header(in, *magicNo, *maxPixVal, *width, *height);
		thing.width = *width;
		thing.height = *height;
		thing.clearCanvas(*width,*height);

		rgbPixelValueType * tempBuffer = new rgbPixelValueType[(*width)*(*height)*3];
		int tempBufSize = (*width)*(*height)*3*sizeof(typename Traits::value_type);
		if (!in.read((char *)tempBuffer,tempBufSize))//Since size of char is 1 we can safely just multiply with the size of the type we are casting to
			std::cout << "The image file is broken. Please inspect the input file." << std::endl;
		for (int i = 0; i < (*width)*(*height)*3; i += 3)
		{
			(thing.buffer[i/3]).r = tempBuffer[i];
			(thing.buffer[i/3]).g = tempBuffer[i+1];
			(thing.buffer[i/3]).b = tempBuffer[i+2];
		}
		convertEndian(thing.buffer,(*width)*(*height));
		delete [] tempBuffer;
		delete magicNo;
		delete maxPixVal;
		delete width;
		delete height;
		return in;
}
//data stream -- out operator. Saves an image to the file.
//simple type:
template <typename AType>
std::ostream & operator<<(std::ostream &out,const PGMImage<AType> & thing){
	typedef pixel_traits<AType> Traits;
	out << Traits::magic_number() << std::endl;
	out << thing.getWidth() << " " << thing.getHeight() << std::endl;
	out << (unsigned int)Traits::max() << std::endl;
	convertEndian(thing.buffer,(thing.getWidth())*(thing.getHeight()));
	if (!out.write(reinterpret_cast<char *>(thing.buffer),(thing.width)*(thing.height)*sizeof(typename Traits::value_type)))
		std::cout << "Could not write output file. Make sure you have permissions" << std::endl;
	convertEndian(thing.buffer,(thing.getWidth())*(thing.getHeight()));		//convert back
	return out;
}
//rgb type:
template<typename AType> std::ostream & operator<< (std::ostream &out,const PGMImage<rgb<AType> > & thing){
	typedef pixel_traits<rgb<AType> > Traits;
	typedef typename Traits::value_type rgbPixelValueType;
	out << Traits::magic_number() << std::endl;
	out << thing.getWidth() << " " << thing.getHeight() << std::endl;
	out << (unsigned int)Traits::max() << std::endl;
	
	convertEndian(thing.buffer,(thing.getWidth())*(thing.getHeight()));
	rgbPixelValueType * tempBuffer = new rgbPixelValueType[(thing.getWidth())*(thing.getHeight())*3];
	int tempBufSize = (thing.getWidth())*(thing.getHeight())*3*sizeof(typename Traits::value_type);
	for (int i = 0; i < (thing.getWidth())*(thing.getHeight())*3; i += 3)
	{
		tempBuffer[i] = (thing.buffer[i/3]).r;
		tempBuffer[i+1] = (thing.buffer[i/3]).g;
		tempBuffer[i+2] = (thing.buffer[i/3]).b;
	}
	
	if (!out.write((char *)tempBuffer,tempBufSize))
		std::cout << "Could not write output file. Make sure you have permissions" << std::endl;
	convertEndian(thing.buffer,(thing.getWidth())*(thing.getHeight()));				//convert back
	return out;
}


/*
	Specialized methods to get hold of the buffer.
	Note: target buffer has to be initialized to the correct size otherwise a segfault may occur
*/
template <typename T>
void getImagePixelBuffer(const PGMImage<T> & inputImg,T * targetBuffer)
{
	long sizeOfImg = inputImg.getWidth()*inputImg.getHeight();
	for (int i = 0; i< sizeOfImg; ++i)
		targetBuffer[i] = inputImg.buffer[i];
}
template <typename T>
void getImagePixelBuffer(const PGMImage<rgb<T> > & inputImg, T * targetBuffer)
{
	long sizeOfImg = inputImg.getWidth()*inputImg.getHeight();
	for (int i = 0; i< sizeOfImg; ++i)
	{
		targetBuffer[i*3] = inputImg.buffer[i].r;
		targetBuffer[i*3+1] = inputImg.buffer[i].g;
		targetBuffer[i*3+2] = inputImg.buffer[i].b;
	}
}
template <typename T>
bool loadImage(PGMImage<T> & myImage,std::string filename){

	std::ifstream in(filename.c_str());
	if (in.is_open())
	{
		in >> myImage;
		in.close();
		return true;
	}
	else
		return false;
}
};
#endif /* PGMIMAGE_HPP_ */
