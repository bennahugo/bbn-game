/*
 * Accumulator_functor.hpp
 *
 *  Created on: Apr 18, 2012
 *      Author: benna
 */
//simple functor to accumulate values (used by the STL transform algorithm
#ifndef ACCUMULATOR_FUNCTOR_HPP_
#define ACCUMULATOR_FUNCTOR_HPP_
template <typename ValueType>
class Accumulator_functor{
private:
	ValueType cumulativeSum;
public:
	Accumulator_functor(bool reserved):cumulativeSum(0){}
	ValueType operator ()(ValueType i) {
		cumulativeSum += i;
		return cumulativeSum;
	}
};


#endif /* ACCUMULATOR_FUNCTOR_HPP_ */
