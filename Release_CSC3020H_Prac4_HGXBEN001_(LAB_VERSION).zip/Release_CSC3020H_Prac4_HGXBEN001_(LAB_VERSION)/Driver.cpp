/*
 * Driver.cpp
 *
 *  Created on: Mar 15, 2012
 *      Author: benna
 *
 *  References: Nehe Productions: http://nehe.gamedev.net
 *  			Sulaco Game Dev: http://www.sulaco.co.za
 *  			Silicon Graphics, Inc. The OpenGL Utility Toolkit (GLUT) Programming Interface
 *  				@@@ ftp://ftp.sgi.com/opengl/glut/glut-3.spec.pdf
 *  			Delphi Developer's Guide to OpenGL, Jon Q. Jacobs, ISBN: 1-55622-657-8
 *  			Interactive Computer Graphics A Top-Down Approach With Shader-Based OpenGL E. 6th, Angel et al. 0-273-75226-X
 *  			Calculus Concepts and Contexts, James Stewart 4th, ISBN: 0-495-56065-0
 *  			American Standard Code For Information Interchange character set:
 *		  			@@@ http://www.theasciicode.com.ar/ascii-control-characters/ascii-codes-8.html
 *		  		Quaternions and Rotation Sequences: A Primer with Applications to Orbits, Aerospace and Virtual Reality, J. B. Kuipers, ISBN 0691102988
 *					--- available from the Chancelor Oppenheimer Library
 *				http://content.gpwiki.org/index.php/OpenGL:Tutorials:Using_Quaternions_to_represent_rotation
 */
#include "Driver.h"

const double PI=3.141592654;
enum ROT_SELECT {RS_X = 0,RS_Y = 1,RS_Z = 2};

//Now set up scene variables and constraints:

ROT_SELECT currentRotSelection;

const float MAX_ZOOM_IN_FACTOR = 1;
const float MAX_ZOOM_OUT_FACTOR = 40;
const float MAX_X_OFFSET = 50;
const float MAX_Y_OFFSET = 50;
const float MAX_Z_OFFSET = 50;

//TIDs
const unsigned int POT_TEX = 1;
const unsigned int POT_BUMP_TEX = 2;
const std::string POT_TEX_NAME = "POT_tex.ppm";
const std::string POT_BUMP_TEX_NAME = "potBumpMap.ppm";
const std::string VERTEX_SHADER = "vertex.vert";
const std::string FRAGMENT_SHADER = "fragment.frag";

//Shader variable pointers:
GLint enabledLightFlagLoc;
GLint enabledTextureFlagLoc;
GLint enabledBumpmapFlagLoc;
GLuint prog;				//program id

//Camera setup:
float cameraHeight = 1.6f;
float cameraRot = -PI/3;
Vector3 focalPoint(0,0,0);
Vector3 cameraUp(0,1,0);

Vector3 PotPos(0,0,0);
Vector3 PotRot(0,0,0);

//Light angles (adjustable, as required):
float lightAngle = PI/6;
float light2Angle = PI/3;
double zoomFactor=3;

bool bumpmap = true;

/********************************************************************************************************************************************
 * Window Event Handlers.
 * These handlers are hooked into the GLWindow framework when the window is created.
 ********************************************************************************************************************************************/
void onInit(void){
	//glEnable(GL_LIGHT0); //now controlled by a uniform flag

	GLfloat lightcol[4] = {1.25, 0.75, 0.0, 1.0};
	GLfloat light2col[4] = {1.25, 1.0, 1.0, 1.0};
	GLfloat light2colSpec[4] = {1.0, 1.0, 1.0, 1.0};
	GLfloat lightcolSpec[4] = {1.25, 0.75, 0.0, 1.0};

	glLightfv(GL_LIGHT0, GL_AMBIENT, lightcol);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, lightcol);
	glLightfv(GL_LIGHT0, GL_SPECULAR, lightcolSpec);

	glLightfv(GL_LIGHT1, GL_AMBIENT, light2col);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, light2col);
	glLightfv(GL_LIGHT1, GL_SPECULAR, light2colSpec);
	//Load the textures

	std::cout << "Loading Textures..." << std::endl;
	std::cout << "---" << POT_TEX_NAME;
	if (GLAdvancedFunctionalities::loadTex(POT_TEX,POT_TEX_NAME))
		std::cout << "<DONE>" << std::endl;
	else
		std::cout << "<ERROR>" << std::endl;
	std::cout << "---" << POT_BUMP_TEX_NAME;
	if (GLAdvancedFunctionalities::loadTex(POT_BUMP_TEX,POT_BUMP_TEX_NAME))
		std::cout << "<DONE>" << std::endl;
	else
		std::cout << "<ERROR>" << std::endl;

	if (glewIsSupported("GL_VERSION_2_0"))
	{
		std::cout << "Loading Shaders..."<<std::endl;
		bool flag = true;
		prog = GLAdvancedFunctionalities::defineShaderProgram();
		std::cout << "---" << VERTEX_SHADER;
		GLuint vshad = GLAdvancedFunctionalities::loadShader(VERTEX_SHADER,GL_VERTEX_SHADER,prog);
		if (!GLAdvancedFunctionalities::objectLoadSuccessful(vshad)){
			std::cout << "<ERROR COMPILING VERTEX SHADER>"<<std::endl;
			flag = false;
		}
		else
			std::cout << "<DONE>"<<std::endl;

		std::cout << "---" << FRAGMENT_SHADER;
		GLuint fshad = GLAdvancedFunctionalities::loadShader(FRAGMENT_SHADER,GL_FRAGMENT_SHADER,prog);
		if (!GLAdvancedFunctionalities::objectLoadSuccessful(fshad)){
			std::cout << "<ERROR COMPILING FRAGMENT SHADER>"<<std::endl;
			flag = false;
		}
		else
			std::cout << "<DONE>"<<std::endl;

		if (flag)
		{
			GLAdvancedFunctionalities::linkAndCompileShaderProgram(prog);
			enabledLightFlagLoc = glGetUniformLocation(prog, "lightEnabled");
			enabledTextureFlagLoc = glGetUniformLocation(prog, "textureEnabled");
			enabledBumpmapFlagLoc = glGetUniformLocation(prog, "bumpmapEnabled");
			glUniform1i(enabledLightFlagLoc,GL_FALSE);
			glUniform1i(enabledLightFlagLoc,GL_FALSE);
			glUniform1i(enabledBumpmapFlagLoc,GL_TRUE);

			GLuint texBase = glGetUniformLocation(prog,"base");
			glUniform1i(texBase,0);
			GLuint texBump = glGetUniformLocation(prog,"texBump");
			glUniform1i(texBump,1);
		}
	}
	else
		std::cout << "OpenGL 2.0 not supported" <<std::endl;
}
//Function to mimic the function available in freeGLUT... takes a NULL terminiated string as arguement (IMPORTANT) and outputs a whole line of text
//onto the screen
void glutStrokeString(void * Font,const char * chars){
	for (int i = 0;; ++i)
	{
		if (chars[i] == NULL)
			break;
		glutStrokeCharacter(GLUT_STROKE_ROMAN,chars[i]);
	}
}
void onDraw(void){
	//Calculate light position and adjust:
	//we dont want the lights to rotate with the camera, so add the camera's rotation to give the illusion of a directional light:
	GLfloat lightpos[4] = {100.0*sin(lightAngle+cameraRot),20.0,100.0*cos(lightAngle+cameraRot), 1.0}; 
	GLfloat light2pos[4] = {100.0*sin(light2Angle+cameraRot),20.0,100.0*cos(light2Angle+cameraRot), 1.0};
	glLightfv(GL_LIGHT0, GL_POSITION, lightpos);
	glLightfv(GL_LIGHT1, GL_POSITION, light2pos);
	//We do some vector math to setup the camera nicely (gluLookAt will do the job perfectly in this assignment):
	Vector3 zoomedCameraEye(zoomFactor*cos(cameraRot),cameraHeight,zoomFactor*sin(cameraRot));
	glPushMatrix();
	glColor3f(1,1,0);
	glTranslatef(-1.1,0,-2.0);
	//Draw some text indicating yaw, pitch and roll:
	glScaled(0.0005,0.0005,0.0005);
	std::ostringstream s;
	s.precision(3);
	s << std::showpoint;
	s << "Roll:" << PotRot.z << NULL;
	glutStrokeString(GLUT_STROKE_ROMAN,s.str().c_str());
	s.str(std::string());
	glPopMatrix();
	glPushMatrix();
	glTranslatef(-1.1,0.15,-2.0);
	glScaled(0.0005,0.0005,0.0005);
	s << "Pitch:" << PotRot.x << NULL;
	glutStrokeString(GLUT_STROKE_ROMAN,s.str().c_str());
	s.str(std::string());
	glPopMatrix();
	glPushMatrix();
	glTranslatef(-1.1,0.3,-2);
	glScaled(0.0005,0.0005,0.0005);
	s << "Yaw:" << PotRot.y << NULL;
	glutStrokeString(GLUT_STROKE_ROMAN,s.str().c_str());
	s.str(std::string());
	glPopMatrix();
	glColor3f(1,1,1);
	glPushMatrix();
	glTranslatef(-1.1,0.75,-2);
	glScaled(0.0005,0.0005,0.0005);
	s << lightpos[0] << ","<< lightpos[1] << "," << lightpos[2] << NULL;
	glutStrokeString(GLUT_STROKE_ROMAN,("Light 1:(" + s.str() + ")").c_str());
	s.str(std::string());
	glPopMatrix();
	glPushMatrix();
	glTranslatef(-1.1,0.6,-2);
	glScaled(0.0005,0.0005,0.0005);
	s << light2pos[0] << ","<< light2pos[1] << "," << light2pos[2] << NULL;
	glutStrokeString(GLUT_STROKE_ROMAN,("Light 2:(" + s.str() + ")").c_str());
	s.str(std::string());
	glPopMatrix();
	gluLookAt(zoomedCameraEye.x,zoomedCameraEye.y,zoomedCameraEye.z,focalPoint.x,focalPoint.y,focalPoint.z,cameraUp.x,cameraUp.y,cameraUp.z);
	//okay we want to translate down to the pot's position to draw it around that center point. Thus we use the matrix stack to save our camera matrix
	glPushMatrix();
	glTranslatef(PotPos.x,PotPos.y,PotPos.z);
	//the pot will rotate round, coordinate, PotPos (so we shift the coordinate system to center at that position), otherwise the pot will rotate round 0,0,0 which is not what is wanted in this case.
	//we also need to use quaternion multiplication sequences to avoid gimblelock.
	Vector3 currentRot;
	Quaternion combinedRot = Quaternion::ConvertFromEuler(PotRot.z*PI/180,PotRot.x*PI/180,PotRot.y*PI/180);
	double* p = new double[16];
	combinedRot.getMatrix().toArray(p);
	glMultMatrixd(p);
	delete[] p;
		glUniform1i(enabledLightFlagLoc,GL_TRUE);		//add some basic lighting to the pot, so that we can actually see the pot's shape instead of a white blob :)
		glUniform1i(enabledTextureFlagLoc,GL_TRUE);
		glColor3f(1.0,1.0,1.0);
		//glEnable(GL_TEXTURE_2D);
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D,POT_BUMP_TEX);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D,POT_TEX);

		glutSolidTeapot(1);				//bobs ye uncle. The teapot is already in the glut framework. No need to load it from a file (although that will be placed here if necessary)
		glUniform1i(enabledLightFlagLoc,GL_FALSE);			//the rest of the scene is not lit, it is beyond the scope of what we are trying to achieve here.
		glUniform1i(enabledTextureFlagLoc,GL_FALSE);
		//glDisable(GL_TEXTURE_2D);
	glPopMatrix();						//restore lookAt matrix

	glPushMatrix();						//Now I just quickly draw a "wire mesh"/platform under the pot so that you can actually notice when it moves. So move down to 0,0,0 and save lookat matrix once more
		glTranslatef(0,0,0);
		//draw a grid:
		glColor3f(0,1,0);
		glLineWidth(3);
		glBegin(GL_LINES);
			for (int i = -50; i <= 50; i+=10){
				glVertex3f(i,-0.735f,-50.0f);
				glVertex3f(i,-0.735f,+50.0f);
				glVertex3f(-50.0f,-0.735f,i);
				glVertex3f(50.0f,-0.735f,i);
			}
		glEnd();
		//Draw some quad to indicate the coordinate: (0,0,0)
		glColor3f(1,0,0);
		glBegin(GL_QUADS);
			glVertex3f(0.5,-0.715f,0.5);
			glVertex3f(-0.5,-0.715f,0.5);
			glVertex3f(-0.5,-0.715f,-0.5);
			glVertex3f(0.5,-0.715f,-0.5);
		glEnd();
	glPopMatrix();												//okies, done drawing restore the camera's state :)
}
void onReshape(int x,int y){

}
//all the non-special keys go here, it is just ASCII values, so no real issues:
void onKeyEvent(unsigned char key,int x, int y){
	switch (key){
		case 27: {				//ESC
			glHelper::deleteWindow();
			exit(0);
			break;
		}
		case 'b':{
			if (bumpmap)
				glUniform1i(enabledBumpmapFlagLoc,GL_FALSE);
			else
				glUniform1i(enabledBumpmapFlagLoc,GL_TRUE);
			bumpmap = !bumpmap;
			break;
		}
		//Pot movement:
		case 's': {
			if (PotPos.z < MAX_Z_OFFSET)
				PotPos.z +=0.05;
			break;
		}
		case 'w': {
			if (PotPos.z > -MAX_Z_OFFSET)
				PotPos.z -=0.05;
			break;
		}
		case 'a': {
			if (PotPos.x > -MAX_X_OFFSET)
				PotPos.x -=0.05;
			break;
		}
		case 'd': {
			if (PotPos.x < MAX_X_OFFSET)
				PotPos.x +=0.05;
			break;
		}
		case 'q': {
			if (PotPos.y < MAX_X_OFFSET)
				PotPos.y +=0.05;
			break;
		}
		case 'z': {
			if (PotPos.y > 0)
				PotPos.y -=0.05;
			break;
		}
		case '9': {
			lightAngle += PI/32;
			if (lightAngle > PI*2)
				lightAngle -= PI*2;
			break;
		}
		case '7': {
			lightAngle -= PI/32;
			if (lightAngle < PI*2)
				lightAngle += PI*2;
			break;
		}
		case '3': {
			light2Angle += PI/32;
			if (light2Angle > PI*2)
				light2Angle -= PI*2;
			break;
		}
		case '1': {
			light2Angle -= PI/32;
			if (light2Angle < PI*2)
				light2Angle += PI*2;
			break;
		}
		case 8: {	//backspace, deal with the rotation mode switching
			if (currentRotSelection == RS_Z)
				currentRotSelection = RS_X;
			else if (currentRotSelection == RS_Y)
				currentRotSelection = RS_Z;
			else
				currentRotSelection = RS_Y;
			break;
		}
		case '-': {
			switch (currentRotSelection)
			{
			case RS_X:
				{
				PotRot.x +=2;
				if (PotRot.x > 360)
					PotRot.x -= 360;
				break;
				}
			case RS_Y:
				{
				PotRot.y +=2;
				if (PotRot.y > 360)
					PotRot.y -= 360;
				break;
				}
			case RS_Z:
				{
				PotRot.z +=2;
				if (PotRot.z > 360)
					PotRot.z -= 360;
				break;
				}
			}
			break;
		}
		case '=': {
			switch (currentRotSelection)
			{
			case RS_X:
				{
				PotRot.x -=2;
				if (PotRot.x < -360)
					PotRot.x += 360;
				break;
				}
			case RS_Y:
				{
				PotRot.y -=2;
				if (PotRot.y < -360)
					PotRot.y += 360;
				break;
				}
			case RS_Z:
				{
				PotRot.z -=2;
				if (PotRot.z < -360)
					PotRot.z += 360;
				break;
				}
			}
			break;
		}
	}
}
//All the special keys are handled here:
void onSpecialKeyEvent(int key,int x, int y){
	switch (key){
		case GLUT_KEY_PAGE_UP: {					//zoom in
			if (zoomFactor > MAX_ZOOM_IN_FACTOR)
				zoomFactor = zoomFactor -0.05;
			break;
		}
		case GLUT_KEY_PAGE_DOWN: {					//zoom out
			if (zoomFactor < MAX_ZOOM_OUT_FACTOR)
				zoomFactor = zoomFactor +0.05;
			break;
		}
		//Camera movement:
		case GLUT_KEY_UP: {
			//if (cameraHeight < MAX_Y_OFFSET)
				cameraHeight += 0.5;
			break;
		}
		case GLUT_KEY_DOWN: {
			//if (cameraHeight > 0)
				cameraHeight -= 0.5;
			break;
		}
		case GLUT_KEY_LEFT: {
			cameraRot += PI/24;
			if (cameraRot > PI*2)
				cameraRot -= PI*2;
			break;
		}
		case GLUT_KEY_RIGHT: {
			cameraRot -= PI/24;
			if (cameraRot < -PI*2)
				cameraRot += PI*2;
			break;
		}
	}
}
void onMouseFunc(int button, int state,int x, int y){

}

int main (int argc, char **argv){
	std::cout << "Program started" <<std::endl;
	glHelper::openWindow(argc,argv,"CSC3020H Prac 4 - OpenGL 2.x Shaders, Texturing and Bumpmapping  - HGXBEN001",30,30,800,600,200,
			&onInit,&onDraw,&onReshape,&onKeyEvent,&onSpecialKeyEvent,&onMouseFunc);
}
