/*
 * Matrix4.h
 *
 *  Created on: Jun 13, 2012
 *      Author: benna
 */

#ifndef MATRIX4_H_
#define MATRIX4_H_

class Matrix4{
private:
	double c1_1,c1_2,c1_3,c1_4,
	c2_1,c2_2,c2_3,c2_4,
	c3_1,c3_2,c3_3,c3_4,
	c4_1,c4_2,c4_3,c4_4;
public:
	Matrix4(double C1_1,double C1_2,double C1_3,double C1_4,
			double C2_1,double C2_2,double C2_3,double C2_4,
			double C3_1,double C3_2,double C3_3,double C3_4,
			double C4_1,double C4_2,double C4_3,double C4_4):
			c1_1(C1_1),c1_2(C1_2),c1_3(C1_3),c1_4(C1_4),
			c2_1(C2_1),c2_2(C2_2),c2_3(C2_3),c2_4(C2_4),
			c3_1(C3_1),c3_2(C3_2),c3_3(C3_3),c3_4(C3_4),
			c4_1(C4_1),c4_2(C4_2),c4_3(C4_3),c4_4(C4_4){}
	virtual ~Matrix4(){}
	void toArray(double * p){
		p[0] = c1_1;
		p[1] = c1_2;
		p[2] = c1_3;
		p[3] = c1_4;
		p[4] = c2_1;
		p[5] = c2_2;
		p[6] = c2_3;
		p[7] = c2_4;
		p[8] = c3_1;
		p[9] = c3_2;
		p[10] = c3_3;
		p[11] = c3_4;
		p[12] = c4_1;
		p[13] = c4_2;
		p[14] = c4_3;
		p[15] = c4_4;
	}
};


#endif /* MATRIX4_H_ */
