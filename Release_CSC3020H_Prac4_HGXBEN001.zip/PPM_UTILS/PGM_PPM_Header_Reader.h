/*
 * PGM_PPM_Header_Reader.h
 *
 *  Created on: Jun 15, 2012
 *      Author: benna
 */
#ifndef PGM_PPM_HEADER_READER_H_
#define PGM_PPM_HEADER_READER_H_
//Method to inspect header returning the magic number and pixel value range
void inspect_header(const std::string & filename,std::string & magic_number, int & max_pixel_value){
	std::string line;
	std::string magic;
	unsigned int width;
	unsigned int height;
	unsigned int range;
	bool hasMagic=false;
	bool hasWidth=false;
	bool hasHeight=false;
	bool hasRange=false;

	std::ifstream inFile(filename.c_str(), std::ios::in | std::ios::binary);
	if (inFile.is_open())
	{
		try{//reads:
			//*magic number
			//*width
			//*height
			//*range
			//*deals with comments appropriately
			while (true){
				inFile >> line;
				boost::algorithm::trim<std::string>(line);
				if (line.at(0)=='#')
				{getline(inFile,line);}
				else if (!hasMagic)
				{
					magic = line;
					hasMagic = true;
				}
				else if (!hasWidth)
				{
					std::stringstream s(line);
					s >> width;
					hasWidth = true;

				}
				else if (!hasHeight)
				{
					std::stringstream s(line);
					s >> height;
					hasHeight = true;
				}
				else if (!(hasRange))
				{
					std::stringstream s(line);
					s >> range;
					hasRange = true;
				}
				else
					break;
			}
		} catch (int e) {std::cout << "Exception while reading. File Header Corrupted? Error " << e << std::endl;}
		magic_number = magic;
		max_pixel_value = range;
		inFile.close();
	}
}
//This overloaded inspect header gets used when reading the files. It returns all header attributes
void inspect_header(std::istream &in,std::string & magic_number, int & max_pixel_value, unsigned int & img_width, unsigned int & img_height){
	std::string line;
	std::string magic;
	unsigned int width;
	unsigned int height;
	unsigned int range;
	bool hasMagic=false;
	bool hasWidth=false;
	bool hasHeight=false;
	bool hasRange=false;

	try{
		while (true){//reads:
			//*magic number
			//*width
			//*height
			//*range
			//*deals with comments appropriately
			getline(in,line);
			boost::algorithm::trim<std::string>(line);
			if (line.at(0)=='#')
			{/*Comment line*/}
			else if (!hasMagic)
			{
				magic = line;
				hasMagic = true;
			}
			else if (!(hasWidth || hasHeight))
			{
				std::stringstream s(line);
				s >> width;
				hasWidth = true;
				s >> height;
				hasHeight = true;
			}
			else if (!(hasRange))
			{
				std::stringstream s(line);
				s >> range;
				hasRange = true;
				break;
			}
		}
	} catch (int e) {std::cout << "Exception while reading. File Header Corrupted? Error " << e << std::endl;}
	magic_number = magic;
	max_pixel_value = range;
	img_width = width;
	img_height = height;
}



#endif /* PGM_PPM_HEADER_READER_H_ */
