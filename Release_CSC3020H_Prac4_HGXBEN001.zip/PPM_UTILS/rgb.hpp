/*
 * RGBPixel.hpp
 *
 *  Created on: Apr 17, 2012
 *      Author: benna
 */

#ifndef RGBPIXEL_HPP_
#define RGBPIXEL_HPP_
template <typename pixelType>
class rgb{
public:
	pixelType r,g,b;
	rgb(pixelType R=0,pixelType G=0,pixelType B=0):r(R),g(G),b(B){};
};


#endif /* RGBPIXEL_HPP_ */
