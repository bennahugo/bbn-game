/*
 * pixel_traits.hpp
 *
 *  Created on: Mar 22, 2012
 *      Author: benna
 */

#ifndef PIXEL_TRAITS_HPP_
#define PIXEL_TRAITS_HPP_
#include <limits>
#include "rgb.hpp"
namespace HGXBEN001{
template <typename T>
class pixel_traits
{
public:
	typedef T pixel_type;
	typedef T value_type;

	static inline value_type min(void) { return 0; }
	static inline value_type max(void) { return std::numeric_limits<T>::max(); }
	static inline unsigned long range(void) { return max() - min() + 1; }
	static std::string magic_number(void) { return std::string("P5"); }
	static inline pixel_type invert(pixel_type value)
	{ 
		return max() - value; 
	}
	static inline value_type CLAMP(float a){
		return a < max() ? a >= min() ? a : min() : max();
	}
	static inline pixel_type darken(pixel_type value, value_type amount){
		pixel_type newVal = ((double)(max()-amount) * (double)(value - min()))/(double)(max()-min());
		return newVal < value ? newVal : value;							//improved formula: cuts out the case where 0 amount leads to a 0 value being generated
	}

	static inline pixel_type lighten(pixel_type value, value_type amount){
		pixel_type newVal = (amount+((double)(max()-amount) * (double)(value - min()))/(max()-min()));
		return newVal > value ? newVal : value;							//improved formula: cuts out the case where 0 amount leads to a 0 value being generated
	}


};
/*
 * Partial specialization to cater for RGB PPM images
 */

template <typename T>
class pixel_traits<rgb<T> >{
public:
		typedef rgb<T> pixel_type;
		typedef T value_type;

		static inline value_type min(void) { return 0; }
		static inline value_type max(void) { return std::numeric_limits<T>::max(); }
		static inline unsigned long range(void) { return max() - min() + 1; }
		static std::string magic_number(void) { return std::string("P6"); }
		static inline pixel_type invert(pixel_type value)
		{
			double Y = (0.299 *(double)value.r + 0.587 *(double)value.g + 0.114 *(double)value.b);
			double I = (0.595716 *(double)value.r - 0.274453 *(double)value.g - 0.321263 *(double)value.b);
			double Q = (0.211456 *(double)value.r - 0.522591 *(double)value.g + 0.311135 *(double)value.b);
			Y = max() - Y;
			rgb<T> newPixel(CLAMP(Y + 0.9564*I + 0.6210*Q),CLAMP(Y - 0.2721*I - 0.6474*Q),CLAMP(Y - 1.1070*I + 1.7046*Q));
			return newPixel;
		}
		static inline value_type CLAMP(float a){
			return a < max() ? a >= min() ? a : min() : max();
		}
		static inline pixel_type darken(pixel_type value, value_type amount){
			double Y = (0.299 *(double)value.r + 0.587 *(double)value.g + 0.114 *(double)value.b);
			double I = (0.595716 *(double)value.r - 0.274453 *(double)value.g - 0.321263 *(double)value.b);
			double Q = (0.211456 *(double)value.r - 0.522591 *(double)value.g + 0.311135 *(double)value.b);
			double newVal = ((double)(max()-amount) * (double)(Y - min()))/(double)(max()-min());
			Y = newVal < Y ? newVal : Y;							//improved formula: cuts out the case where 0 amount leads to a 0 value being generated

			rgb<T> newPixel(CLAMP(Y + 0.9564*I + 0.6210*Q),CLAMP(Y - 0.2721*I - 0.6474*Q),CLAMP(Y - 1.1070*I + 1.7046*Q));
			return newPixel;
		}

		static inline pixel_type lighten(pixel_type value, value_type amount){
			double Y = (0.299 *(double)value.r + 0.587 *(double)value.g + 0.114 *(double)value.b);
			double I = (0.595716 *(double)value.r - 0.274453 *(double)value.g - 0.321263 *(double)value.b);
			double Q = (0.211456 *(double)value.r - 0.522591 *(double)value.g + 0.311135 *(double)value.b);
			double newVal = (amount+((double)(max()-amount) * (double)(Y - min()))/(max()-min()));
			Y = newVal > Y ? newVal : Y;							//improved formula: cuts out the case where 0 amount leads to a 0 value being generated

			rgb<T> newPixel(CLAMP(Y + 0.9564*I + 0.6210*Q),CLAMP(Y - 0.2721*I - 0.6474*Q),CLAMP(Y - 1.1070*I + 1.7046*Q));
			return newPixel;
		}
};
}
#endif /* PIXEL_TRAITS_HPP_ */
