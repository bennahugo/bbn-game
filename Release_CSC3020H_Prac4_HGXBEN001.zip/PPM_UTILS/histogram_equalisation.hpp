/*
 * histogram_equalisation.hpp
 *
 *  Created on: 17 Apr 2012
 *      Author: hgxben001
 */

#ifndef HISTOGRAM_EQUALISATION_HPP_
#define HISTOGRAM_EQUALISATION_HPP_
#include "pixel_traits.hpp"
#include "PGMImage.hpp"
#include "make_histogram_functor.hpp"
#include "apply_cfd_functor.hpp"
#include <algorithm>
#include <vector>
#include "Accumulator_functor.hpp"
namespace HGXBEN001{

template <typename pixelType>
void histogram_equalisation(PGMImage<pixelType> & I)
{
	typedef pixel_traits<pixelType> Traits;
	/* Declare vector histogram */
	std::vector<unsigned long> * vHist = new std::vector<unsigned long>(Traits::range());						//create a vector with range() indices (one for each intensity)

	std::fill<std::vector<unsigned long>::iterator, unsigned long >(vHist->begin(),vHist->end(), 0);
	/* use img_for_each and make_histogram to populate the histogram */
	make_histogram_functor<pixelType> * hf= new make_histogram_functor<pixelType>(false,*vHist);
	img_for_each<typename PGMImage<pixelType>::Iterator,make_histogram_functor<pixelType> >(I.begin(),I.end(),* hf);
	/* CFD calculation */
	std::vector<unsigned long> * vCDF = new std::vector<unsigned long>(Traits::range());
	*vCDF->begin() = *vHist->begin();
	Accumulator_functor<unsigned long> a(false);
	std::copy<std::vector<unsigned long>::iterator,std::vector<unsigned long>::iterator >(vHist->begin(),vHist->end(),vCDF->begin());
	std::transform<std::vector<unsigned long>::iterator,std::vector<unsigned long>::iterator>
		(vCDF->begin(),vCDF->end(),vCDF->begin(),a);
	/* use img_transform + apply_cfd to equalise image */
	unsigned long nr_of_pixels = I.getWidth()*I.getHeight();
	typename Traits::value_type pixelRangeMin1 = Traits::range() - 1;
	typename Traits::value_type cdfMin = *std::min_element<std::vector<unsigned long>::iterator >(vCDF->begin(),vCDF->end());
	apply_cfd_functor<pixelType> * acf = new apply_cfd_functor<pixelType>(nr_of_pixels,pixelRangeMin1,cdfMin,*vCDF);
	img_transform(I.begin(),I.end(),I.begin(),* acf);

	delete vHist;
	delete vCDF;
	delete hf;
	delete acf;
}
//RGB need to do what is described above for all 3 channels respectively
template <typename pixelType>
void histogram_equalisation(PGMImage<rgb<pixelType> > & I)
{
	typedef pixel_traits<pixelType> Traits;
	/* Declare vector histogram */
	std::vector<unsigned long> * vHistR = new std::vector<unsigned long>(Traits::range());						//create a vector with range() indices (one for each intensity)
	std::fill<std::vector<unsigned long>::iterator, unsigned long >(vHistR->begin(),vHistR->end(), 0);
	std::vector<unsigned long> * vHistG = new std::vector<unsigned long>(Traits::range());						//create a vector with range() indices (one for each intensity)
	std::fill<std::vector<unsigned long>::iterator, unsigned long >(vHistG->begin(),vHistG->end(), 0);
	std::vector<unsigned long> * vHistB = new std::vector<unsigned long>(Traits::range());						//create a vector with range() indices (one for each intensity)
	std::fill<std::vector<unsigned long>::iterator, unsigned long >(vHistB->begin(),vHistB->end(), 0);

	/* use img_for_each and make_histogram to populate the histogram */
	make_histogram_functor<rgb<pixelType> > * hf= new make_histogram_functor<rgb<pixelType> >(false,*vHistR,*vHistG,*vHistB);
	img_for_each<typename PGMImage<rgb<pixelType> >::Iterator,make_histogram_functor<rgb<pixelType> > >(I.begin(),I.end(),* hf);

	/* CFD calculation */
	std::vector<unsigned long> * vCDFR = new std::vector<unsigned long>(Traits::range());
	*vCDFR->begin() = *vHistR->begin();
	Accumulator_functor<unsigned long> * a = new Accumulator_functor<unsigned long>(false);
	std::copy<std::vector<unsigned long>::iterator,std::vector<unsigned long>::iterator >(vHistR->begin(),vHistR->end(),vCDFR->begin());
	std::transform<std::vector<unsigned long>::iterator,std::vector<unsigned long>::iterator>
		(vCDFR->begin(),vCDFR->end(),vCDFR->begin(),*a);

	std::vector<unsigned long> * vCDFG = new std::vector<unsigned long>(Traits::range());
	delete a;
	a = new Accumulator_functor<unsigned long>(false);
	*vCDFG->begin() = *vHistG->begin();
	std::copy<std::vector<unsigned long>::iterator,std::vector<unsigned long>::iterator >(vHistG->begin(),vHistG->end(),vCDFG->begin());
	std::transform<std::vector<unsigned long>::iterator,std::vector<unsigned long>::iterator>
		(vCDFG->begin(),vCDFG->end(),vCDFG->begin(),*a);

	std::vector<unsigned long> * vCDFB = new std::vector<unsigned long>(Traits::range());
	*vCDFB->begin() = *vHistB->begin();
	delete a;
	a = new Accumulator_functor<unsigned long>(false);
	std::copy<std::vector<unsigned long>::iterator,std::vector<unsigned long>::iterator >(vHistB->begin(),vHistB->end(),vCDFB->begin());
	std::transform<std::vector<unsigned long>::iterator,std::vector<unsigned long>::iterator>
		(vCDFB->begin(),vCDFB->end(),vCDFB->begin(),*a);

	/* use img_transform + apply_cfd to equalise image */
	unsigned long nr_of_pixels = I.getWidth()*I.getHeight();
	typename Traits::value_type pixelRangeMin1 = Traits::range() - 1;
	typename Traits::value_type cdfMinR = *std::min_element<std::vector<unsigned long>::iterator >(vCDFR->begin(),vCDFR->end());
	typename Traits::value_type cdfMinG = *std::min_element<std::vector<unsigned long>::iterator >(vCDFG->begin(),vCDFG->end());
	typename Traits::value_type cdfMinB = *std::min_element<std::vector<unsigned long>::iterator >(vCDFB->begin(),vCDFB->end());
	apply_cfd_functor<rgb<pixelType> > * acf = new apply_cfd_functor<rgb<pixelType> >(nr_of_pixels,pixelRangeMin1,cdfMinR,cdfMinG,cdfMinB,*vCDFR,*vCDFG,*vCDFB);
	img_transform(I.begin(),I.end(),I.begin(),* acf);
	delete a;
	delete vHistR;
	delete vHistG;
	delete vHistB;
	delete vCDFR;
	delete vCDFG;
	delete vCDFB;
	delete hf;
	delete acf;
}
}
#endif /* HISTOGRAM_EQUALISATION_HPP_ */
