/*
 * make_histogram_functor.hpp
 *
 *  Created on: 17 Apr 2012
 *      Author: hgxben001
 */

#ifndef MAKE_HISTOGRAM_FUNCTOR_HPP_
#define MAKE_HISTOGRAM_FUNCTOR_HPP_
#include "pixel_traits.hpp"
#include "rgb.hpp"
#include <vector>
//Simply put: we need a "bucket" for each pixel (ie 0-range(type)). For RGB we need 3 "buckets" per pixel
namespace HGXBEN001{
template <typename pixelType>
class make_histogram_functor{
private:
	typedef pixel_traits<pixelType> Traits;
	std::vector<unsigned long> & container;
public:
	make_histogram_functor(bool reserved,std::vector<unsigned long> & vStorage):container(vStorage){}
	void operator()(const typename Traits::pixel_type & p) const{
		container.at(p) = container.at(p)+1;
	}
};
template <typename pixelType>
class make_histogram_functor<rgb<pixelType> >{
private:
	typedef pixel_traits<rgb<pixelType> > Traits;
	std::vector<unsigned long> & containerR;
	std::vector<unsigned long> & containerG;
	std::vector<unsigned long> & containerB;
public:
	make_histogram_functor(bool reserved,std::vector<unsigned long> & vRStorage,std::vector<unsigned long> & vGStorage,std::vector<unsigned long> & vBStorage):
		containerR(vRStorage),containerG(vGStorage),containerB(vBStorage){}
	void operator()(const typename Traits::pixel_type & p) const{
		containerR.at(p.r) = containerR.at(p.r)+1;
		containerG.at(p.g) = containerG.at(p.g)+1;
		containerB.at(p.b) = containerB.at(p.b)+1;
	}
};
}
#endif /* MAKE_HISTOGRAM_FUNCTOR_HPP_ */
