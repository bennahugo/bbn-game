/*
 * lighten_functor.hpp
 *
 *  Created on: 17 Apr 2012
 *      Author: hgxben001
 */

#ifndef LIGHTEN_FUNCTOR_HPP_
#define LIGHTEN_FUNCTOR_HPP_
#include "pixel_traits.hpp"
namespace HGXBEN001{
template <typename pixelType>
class lighten_functor{
private:
	typedef pixel_traits<pixelType> Traits;
	typename Traits::value_type amount;
public:
	lighten_functor(bool reserved,typename Traits::value_type Amount=0):amount(Amount){}
	typename Traits::pixel_type operator()(const typename Traits::pixel_type & p) const{
		return Traits::lighten(p,amount);
	}
};
}
#endif /* LIGHTEN_FUNCTOR_HPP_ */
