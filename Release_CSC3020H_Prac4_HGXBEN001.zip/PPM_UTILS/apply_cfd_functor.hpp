/*
 * apply_cfd_functor.hpp
 *
 *  Created on: Apr 18, 2012
 *      Author: benna
 */

#ifndef APPLY_CFD_FUNCTOR_HPP_
#define APPLY_CFD_FUNCTOR_HPP_
#include "pixel_traits.hpp"
#include "rgb.hpp"
#include <vector>
//basically: this functor will take range - 1, CFDmin, pixelCount and the CFD piecewise function (a vector) as arguements upon construction.
//For the case of RGB we will have each of these values per channel. We then simply apply the formula as stated in the spec.
namespace HGXBEN001{
template <typename pixelType>
class apply_cfd_functor{
private:
	typedef pixel_traits<pixelType> Traits;
	unsigned long nr_of_pixels;
	typename Traits::value_type pixelRangeMin1;
	typename Traits::value_type cdfMin;
	const std::vector<unsigned long> * vCDF;
public:
	apply_cfd_functor(unsigned long pixel_count,typename Traits::value_type rangeMinus1,typename Traits::value_type MinOfCDF,
			const std::vector<unsigned long> & CDF):
		nr_of_pixels(pixel_count),pixelRangeMin1(rangeMinus1),cdfMin(MinOfCDF),vCDF(&CDF){}

	typename Traits::pixel_type operator()(const typename Traits::pixel_type & p) const{
		typename Traits::pixel_type result = (vCDF->at(p)-cdfMin)/(float)(nr_of_pixels-cdfMin)*pixelRangeMin1;

		return result;
	}
};
template <typename pixelType>
class apply_cfd_functor<rgb<pixelType> >{
private:
	typedef pixel_traits<rgb<pixelType> > Traits;
	unsigned long nr_of_pixels;
	typename Traits::value_type pixelRangeMin1;
	typename Traits::value_type cdfRMin;
	typename Traits::value_type cdfGMin;
	typename Traits::value_type cdfBMin;
	const std::vector<unsigned long> * vRCDF;
	const std::vector<unsigned long> * vGCDF;
	const std::vector<unsigned long> * vBCDF;
public:
	apply_cfd_functor(unsigned long pixel_count,typename Traits::value_type rangeMinus1,typename Traits::value_type MinOfRCDF,
			typename Traits::value_type MinOfGCDF,typename Traits::value_type MinOfBCDF,
			const std::vector<unsigned long> & RCDF,const std::vector<unsigned long> & GCDF,const std::vector<unsigned long> & BCDF):
		nr_of_pixels(pixel_count),pixelRangeMin1(rangeMinus1),cdfRMin(MinOfRCDF),cdfGMin(MinOfGCDF),cdfBMin(MinOfBCDF),vRCDF(&RCDF),vGCDF(&GCDF),vBCDF(&BCDF){}

	typename Traits::pixel_type operator()(const typename Traits::pixel_type & p) const{
		float R = Traits::CLAMP((vRCDF->at(p.r)-cdfRMin)/(float)(nr_of_pixels-cdfRMin)*pixelRangeMin1);
		float G = Traits::CLAMP((vGCDF->at(p.g)-cdfGMin)/(float)(nr_of_pixels-cdfGMin)*pixelRangeMin1);
		float B = Traits::CLAMP((vBCDF->at(p.b)-cdfBMin)/(float)(nr_of_pixels-cdfBMin)*pixelRangeMin1);

		rgb<pixelType> newPixel(R,G,B);
		return newPixel;
	}
};
}
#endif /* APPLY_CFD_FUNCTOR_HPP_ */
