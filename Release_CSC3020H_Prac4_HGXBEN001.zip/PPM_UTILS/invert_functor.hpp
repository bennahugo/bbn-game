/*
 * invert_functor.hpp
 *
 *  Created on: 17 Apr 2012
 *      Author: hgxben001
 */

#ifndef INVERT_FUNCTOR_HPP_
#define INVERT_FUNCTOR_HPP_
#include "pixel_traits.hpp"
namespace HGXBEN001{
template <typename pixelType>
class invert_functor{
private:
	typedef pixel_traits<pixelType> Traits;
public:
	invert_functor(bool reserved){}
	typename Traits::pixel_type operator()(const typename Traits::pixel_type & p) const{
		return Traits::invert(p);
	}
};
}
#endif /* LIGHTEN_FUNCTOR_HPP_ */
