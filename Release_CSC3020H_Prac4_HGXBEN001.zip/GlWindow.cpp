/*
 * GlWindow.cpp
 *
 *  Created on: Mar 15, 2012
 *      Author: benna
 *
 *  Using the OpenGL GLUT bindings to create a window
 *  References: Nehe Productions: http://nehe.gamedev.net
 *  			Sulaco Game Dev: http://www.sulaco.co.za
 *  			Silicon Graphics, Inc. The OpenGL Utility Toolkit (GLUT) Programming Interface
 *  				@@@ ftp://ftp.sgi.com/opengl/glut/glut-3.spec.pdf
 *  			Delphi Developer's Guide to OpenGL, Jon Q. Jacobs, ISBN: 1-55622-657-8
 *  			Interactive Computer Graphics A Top-Down Approach With Shader-Based OpenGL E. 6th, Angel et al. 0-273-75226-X
 */
#include "GlWindow.hpp"
#include <iostream>
//essentially "local variables":
int windowID;
float perspectiveDepth;
void (*drawHook)(void) = NULL;		//user defined hook into the default draw event handler
void (*resizeHook)(int,int) = NULL;		//user defined hook into the default draw event handler

void drawHandler(){
	glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);	//we want to clear the current buffers so that we don't get artifacts from one scene to the next
	glLoadIdentity();//the identity modelview matrix
		(*drawHook)();
	glutSwapBuffers();//swap backbuffer that is now fully rendered onto
}
void resizeHandler(int Width,int Height){
	glViewport(0,0,Width,Height);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	if (Height > 0)			//we don't want divide by 0 problems, so just cancel out this case, the user won't be able to see anything anyway
		gluPerspective(45.0f,(GLfloat)Width/(GLfloat)Height,0.1f,perspectiveDepth);	// setup a projection view-viewport (50 units in depth)
	glMatrixMode(GL_MODELVIEW);

	(*resizeHook)(Width,Height);
}

void initialSetup(int width, int height, float depth){		//essentially a "local/hidden method"
	//After window creation we need to set up a perspective projection, where depth decreases the size of objects.
	//first clear the depth buffer and set a default blue-ish color for empty space
	glClearColor(0.2f,0.4f,7.0f,100.0f);
	glClearDepth(1.0);
	//Since this is 3D we want the depth test to be enabled so that cliping and drawing at depth is done correctly.
	glDepthFunc(GL_LESS);
	glEnable(GL_DEPTH_TEST);
	//Now we need the correct viewing: perspective with modelview styled viewport:
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0f,(GLfloat)width/(GLfloat)height,0.1f,depth);	// setup a projection view-viewport (50 units in depth)
	perspectiveDepth = depth;
	glMatrixMode(GL_MODELVIEW);
}

void kb(unsigned char key,int x, int y){
	std::cout << "kb receive" << std::endl;
}

void glHelper::openWindow(int argc, char **argv, char * title, int x, int y, int width, int height, float depth,
		void (*onInit)(void),
		void (*onDraw)(void),
		void (*onReshape)(int,int),
		void (*onKeyEvent)(unsigned char,int, int),
		void (*onSpecialKeyEvent)(int,int, int),
		void (*onMouseFunc)(int, int,int, int)){
	//This procedure is pretty much the standard way of linking with the GLUT bindings. This is clearly described by the SGI API

	//INIT GLUT:
	std::cout << "Setting up GLUT-powered window system...";
	glutInit(&argc,argv);

	//Indicate the suggested window size to GLUT
	glutInitWindowSize(width,height);
	glutInitWindowPosition(x, y);

	/*GLUT RGBA Bit mask to select an RGBA mode window.
	 *GLUT DOUBLE Bit mask to select a double buffered window.
	 *GLUT DEPTH Bit mask to select a window with a depth buffer.
	 *GLUT ALPHA Bit mask to select a window with an alpha component to the color buffer(s).
	 */

	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
	//now create the window
	windowID = glutCreateWindow(title);

	//callback method pointers:
	drawHook = onDraw;
	resizeHook = onReshape;
	glutDisplayFunc(&drawHandler);
	glutIdleFunc(&drawHandler);
	glutKeyboardFunc(&*onKeyEvent);
	glutSpecialFunc(&*onSpecialKeyEvent);
	glutMouseFunc(&*onMouseFunc);
	glutReshapeFunc(&resizeHandler);

	initialSetup(width,height,depth);
	glewInit();

	std::cout << "<DONE>" << std::endl;
	(*onInit)();
	//finally enter the main loop:
	glutMainLoop();					//this loop does not return until the rendering is done (exited)
}

void glHelper::deleteWindow(){
	glutDestroyWindow(windowID);
}

