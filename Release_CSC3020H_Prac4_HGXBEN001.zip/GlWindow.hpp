/*
 * GlWindow.hpp
 *
 *  Created on: Mar 15, 2012
 *      Author: benna
 *
 *  Using the OpenGL GLUT bindings to create a window
 *  References: Nehe Productions: http://nehe.gamedev.net
 *  			Sulaco Game Dev: http://www.sulaco.co.za
 *  			Silicon Graphics, Inc. The OpenGL Utility Toolkit (GLUT) Programming Interface
 *  				@@@ ftp://ftp.sgi.com/opengl/glut/glut-3.spec.pdf
 *  			Delphi Developer's Guide to OpenGL, Jon Q. Jacobs, ISBN: 1-55622-657-8
 *  			Interactive Computer Graphics A Top-Down Approach With Shader-Based OpenGL E. 6th, Angel et al. 0-273-75226-X
 */

#ifndef GLWINDOW_HPP_
#define GLWINDOW_HPP_
#include <GL/glew.h>
#include <GL/glut.h>			//According to SGI only this header should be included.
namespace glHelper{
	void openWindow(int argc, char **argv, char * title, int x, int y, int width, int height, float depth,
			void (*onInit)(void),
			void (*onDraw)(void),
			void (*onReshape)(int,int),
			void (*onKeyEvent)(unsigned char,int, int),
			void (*onSpecialKeyEvent)(int,int, int),
			void (*onMouseFunc)(int, int,int, int));
	void deleteWindow();
}

#endif /* GLWINDOW_HPP_ */
