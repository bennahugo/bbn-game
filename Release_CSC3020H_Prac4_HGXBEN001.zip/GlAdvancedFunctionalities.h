/*
 * GlAdvancedFunctionalities.h
 *
 *  Created on: Jun 14, 2012
 *      Author: benna
 */

#ifndef GLADVANCEDFUNCTIONALITIES_H_
#define GLADVANCEDFUNCTIONALITIES_H_

#include <GL/glew.h>
#include <GL/glut.h>			//According to SGI only this header should be included.
#include <string>
#include <fstream>
#include "PPM_UTILS/PGMImage.hpp"
#include "PPM_UTILS/rgb.hpp"
namespace GLAdvancedFunctionalities{
	//Exceptions:
	class IllegalImageType:std::exception{};
	class FileNotFound: std::exception{};
	/*
	 * Method to load a PPM or PGM texture from a file into OpenGL
	 */

	bool loadTex(unsigned int TEX_ID,const std::string & TEX_FILE_NAME){
		glBindTexture(GL_TEXTURE_2D, TEX_ID);
		glPixelStorei(GL_UNPACK_ALIGNMENT,1);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

		bool result = true;
		using namespace HGXBEN001;
		std::string * magic = new std::string;
		int * maxRange = new int;
		inspect_header(TEX_FILE_NAME,*magic,*maxRange);
		try
		{
			if (*magic == "P6"){
				PGMImage<rgb<unsigned char> > * img = new PGMImage<rgb<unsigned char> >;
				loadImage<rgb<unsigned char> >(*img,TEX_FILE_NAME);
				unsigned char * buf = new unsigned char[(*img).getHeight()*(*img).getWidth()*3];
				getImagePixelBuffer<unsigned char>(*img,buf);
				glTexImage2D (GL_TEXTURE_2D, 0, GL_RGB, (*img).getWidth(), (*img).getHeight(), 0, GL_RGB, GL_UNSIGNED_BYTE, buf);
				delete img;
			}
			else if (*magic == "P5"){
				PGMImage<unsigned char> * img = new PGMImage<unsigned char>;
				loadImage<unsigned char>(*img,TEX_FILE_NAME);
				unsigned char * buf = new unsigned char[(*img).getHeight()*(*img).getWidth()];
				getImagePixelBuffer<unsigned char>(*img,buf);
				glTexImage2D (GL_TEXTURE_2D, 0, GL_LUMINANCE, (*img).getWidth(), (*img).getHeight(), 0, GL_LUMINANCE, GL_UNSIGNED_BYTE, buf);
				delete img;
			}
			else
				throw IllegalImageType();
		}
		catch (IllegalImageType & e)
		{
			result = false;
		}
		delete magic; magic = NULL;
		delete maxRange; maxRange = NULL;
		return result;
	}
	/********************************************************************************************************************************************
	* Method to load text file
	********************************************************************************************************************************************/
	std::string loadTextFileIntoOneLine(std::string filename) throw (FileNotFound){
		std::ifstream in(filename.c_str());
		std::string s;
		if (in.is_open())
		{
			while (!in.eof()){
				std::string t;
				getline(in,t);
				s.append(t);
			}
			in.close();
			return s;
		}
		else
			throw FileNotFound();
	}
	/********************************************************************************************************************************************
	 * Define a shader program (to be done before loading a shader)
	********************************************************************************************************************************************/
	GLuint defineShaderProgram(){
		return glCreateProgram();
	}
	/********************************************************************************************************************************************
	* Finalize shader program (to be done after all shaders are loaded)
	********************************************************************************************************************************************/
	GLuint linkAndCompileShaderProgram(GLuint shaderProgramId){
		glLinkProgram(shaderProgramId);
		glUseProgram(shaderProgramId);
	}
	/********************************************************************************************************************************************
	 * Method to handle shader loading
	 ********************************************************************************************************************************************/
	GLuint loadShader(std::string filename, unsigned int type, GLuint shaderProgramId){
		//Shader IDs
		GLuint s;
		s = glCreateShader(type);
		std::string data = loadTextFileIntoOneLine(filename);
		const char * dataptr = data.c_str();
		glShaderSource(s, 1, &dataptr,NULL);
		glCompileShader(s);
		glAttachShader(shaderProgramId,s);
		return s;
	}
	bool objectLoadSuccessful(GLuint id){
		int * flag = new int();
		glGetShaderiv(id, GL_COMPILE_STATUS, flag);
		if (*flag == GL_TRUE){
			delete flag;
			return true;
		}
		else
		{
			delete flag;
			return false;
		}
	}
}


#endif /* GLADVANCEDFUNCTIONALITIES_H_ */
